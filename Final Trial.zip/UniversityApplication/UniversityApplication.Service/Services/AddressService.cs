﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data;
using UniversityApplication.Data.Entities;
using UniversityApplication.Data.Interfaces;
using UniversityApplication.Service.Interfaces;

namespace UniversityApplication.Service.Services
{
    public class AddressService : IAddressService
    {
        private readonly IAddressRepository _addressRepository;

        public AddressService(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        public Address GetAddressById(int id)
        {
            return _addressRepository.GetAddressById(id);
        }

        public IEnumerable<Address> GetAddresses()
        {
            return _addressRepository.GetAddresses();
        }
    }
}
