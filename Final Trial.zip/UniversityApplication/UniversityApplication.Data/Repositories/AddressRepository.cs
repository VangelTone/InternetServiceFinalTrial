﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;
using UniversityApplication.Data.Interfaces;

namespace UniversityApplication.Data.Repositories
{
    public class AddressRepository : IAddressRepository
    {
        private readonly UniversityDataContext _dataContext;

        public AddressRepository(UniversityDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public Address GetAddressById(int id)
        {
            return _dataContext.Addresses.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Address> GetAddresses()
        {
            return _dataContext.Addresses.ToList();
        }
    }
}
