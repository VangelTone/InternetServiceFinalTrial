﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace UniversityApplication.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Addresses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Street = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    City = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    Country = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Addresses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime", nullable: true),
                    Mail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StudentIndex = table.Column<string>(type: "char(4)", nullable: false),
                    GPA = table.Column<decimal>(type: "decimal(3,2)", nullable: true),
                    AddressId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Students_Addresses_AddressId",
                        column: x => x.AddressId,
                        principalTable: "Addresses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Addresses",
                columns: new[] { "Id", "City", "Country", "Street" },
                values: new object[,]
                {
                    { 1, "London", "UK", "Frying Pan Road" },
                    { 2, "Cincinnati", "USA", "Error Place" },
                    { 3, "Rome", "Italy", "Bad Route Road" },
                    { 4, "Las Vegas", "USA", "Pillow Talk Court" },
                    { 5, "Berlin", "Germany", "This Street" }
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "AddressId", "DateOfBirth", "EnrollmentDate", "FirstName", "GPA", "LastName", "Mail", "StudentIndex" },
                values: new object[,]
                {
                    { 3, 1, null, new DateTime(2020, 3, 1, 0, 0, 0, 0, DateTimeKind.Local), "Kristel", null, "Madison", "Kristel.Madison@mail.com", "3121" },
                    { 1, 2, null, new DateTime(2019, 3, 1, 0, 0, 0, 0, DateTimeKind.Local), "Kessidy", null, "Truman", "Kassidy.Truman@mail.com", "3516" },
                    { 4, 3, null, new DateTime(2021, 3, 1, 0, 0, 0, 0, DateTimeKind.Local), "Lyndsey", null, "Albers", "Lyndsey.Albers@mail.com", "1415" },
                    { 5, 4, null, new DateTime(2019, 3, 1, 0, 0, 0, 0, DateTimeKind.Local), "Alishia", null, "Gabriels", "Alishia.Gabriels@mail.com", "3717" },
                    { 2, 5, null, new DateTime(2018, 3, 1, 0, 0, 0, 0, DateTimeKind.Local), "Christobel", null, "Bezuidenhout", "Christobel.Bezuidenhout@mail.com", "1241" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Students_AddressId",
                table: "Students",
                column: "AddressId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Addresses");
        }
    }
}
