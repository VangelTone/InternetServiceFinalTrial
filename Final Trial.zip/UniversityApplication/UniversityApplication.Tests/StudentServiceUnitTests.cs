using AutoMapper;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using UniversityApplication.Data.Entities;
using UniversityApplication.Data.Interfaces;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Services;
using Xunit;

namespace UniversityApplication.Tests
{
    public class StudentServiceUnitTests
    {
        IStudentRepository studentRepo;
        IMapper mapper;
        Mock<IStudentRepository> studentRepoMock = new Mock<IStudentRepository>();
        Student student;
        StudentDTO studentDTO;
        Mock<IMapper> mapperMock = new Mock<IMapper>();
        List<Student> students = new List<Student>();
        List<StudentDTO> studentDTOList = new List<StudentDTO>();

        private void SetupMocks()
        {
            studentRepo = studentRepoMock.Object;
            mapper = mapperMock.Object;
        }

        private void SetupStudentDTOMocks()
        {
            student = GetStudent();
            //var studentDTO = GetStudentDTO();

            mapperMock.Setup(o => o.Map<StudentDTO>(student))
                .Returns(GetStudentDTO());
        }
        private void SetupStudentDTOListMocks()
        {
            studentDTO = GetStudentDTO();
            var studentDTO2 = GetStudentDTO();
            studentDTO2.Id = 2;

            studentDTOList.Add(studentDTO);
            studentDTOList.Add(studentDTO2);

            students = GetStudents();

            mapperMock.Setup(o => o.Map<List<StudentDTO>>(students))
                .Returns(studentDTOList);
        }

        private static Student GetStudent()
        {
            return new Student
            {
                Id = 4,
                FirstName = "Lyndsey",
                LastName = "Albers",
                StudentIndex = "1415",
                AddressId = 3,
                Mail = "Lyndsey.Albers@mail.com",
                EnrollmentDate = DateTime.Today.AddYears(-1)
            };
        }

        private static StudentDTO GetStudentDTO()
        {
            return new StudentDTO
            {
                Id = 4,
                FirstName = "Lyndsey",
                LastName = "Albers",
                StudentIndex = "1415",
                AddressId = 3,
                Mail = "Lyndsey.Albers@mail.com",
                EnrollmentDate = DateTime.Today.AddYears(-1)
            };
        }

        private static List<Student> GetStudents()
        {
            return new List<Student>()
            {
                new Student()
                {
                Id = 1,
                AddressId = 3,
                EnrollmentDate = new DateTime(2021, 3, 1, 0, 0, 0, 0, DateTimeKind.Local),
                FirstName = "Lyndsey",
                LastName = "Albers",
                Mail = "Lyndsey.Albers@mail.com",
                StudentIndex = "1415"
                },
                 new Student()
                 {
                     Id = 2,
                     FirstName = "Christobel",
                     LastName = "Bezuidenhout",
                     StudentIndex = "1241",
                     AddressId = 5,
                     Mail = "Christobel.Bezuidenhout@mail.com",
                     EnrollmentDate = DateTime.Today.AddYears(-4)
                 },
               new Student()
               {
                   Id = 3,
                   FirstName = "Kristel",
                   LastName = "Madison",
                   StudentIndex = "3121",
                   AddressId = 1,
                   Mail = "Kristel.Madison@mail.com",
                   EnrollmentDate = DateTime.Today.AddYears(-2)
               }
            };
        }

        [Fact]
        public void GetStudentByIdWhenCalledReturnsStudent()
        {
            //Arrange
            student = GetStudent();
            SetupMocks();
            SetupStudentDTOMocks();

            studentRepoMock
                .Setup(o => o.GetStudentById(It.IsAny<int>()))
                .Returns(student);

            var studentService = new StudentService(studentRepo, mapper);
            int id = 1;


            //Act 
            StudentDTO response = studentService.GetStudentById(id);

            //Assert
            Assert.True(response != null);
            Assert.NotNull(response);
            Assert.Equal(4, response.Id);
            Assert.NotEqual(id, response.Id);
        }

        [Fact]
        public void GetStudentsWhenCalledReturnsStudent()
        {
            //Arrage 
            students = GetStudents();
            SetupMocks();
            SetupStudentDTOListMocks();

            studentRepoMock
            .Setup(o => o.GetStudents())
            .Returns(students);

            var studentService = new StudentService(studentRepo, mapper);

            // Act
            List<StudentDTO> response = studentService.GetStudents();

            // Assert
            Assert.True(response != null);
        }

        [Fact]
        public void GetStudentsWhenCalledOnThreeStudentsReturnsTwoStudent()
        {
            //Arrange
            students = GetStudents();
            SetupMocks();
            SetupStudentDTOListMocks();

            studentRepoMock
                .Setup(o => o.GetStudents())
                .Returns(students);

            var studentService = new StudentService(studentRepo, mapper);

            //Act
            List<StudentDTO> response = studentService.GetStudents();

            //Assert
            Assert.NotNull(response);
            Assert.Equal(2, response.Count());
            Assert.NotEqual(1, response.Count());
        }
    }
}
