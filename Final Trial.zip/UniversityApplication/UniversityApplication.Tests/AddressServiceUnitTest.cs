﻿using AutoMapper;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using UniversityApplication.Data.Entities;
using UniversityApplication.Data.Interfaces;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Services;
using Xunit;

namespace UniversityApplication.Tests
{
    public class AddressServiceUnitTests
    {
        IAddressRepository addressRepo;
        IMapper mapper;
        Mock<IAddressRepository> addressRepoMock = new Mock<IAddressRepository>();
        Address address;
        AddressDTO addressDTO;
        Mock<IMapper> mapperMock = new Mock<IMapper>();
        List<Address> addresses = new List<Address>();
        List<AddressDTO> addressDTOList = new List<AddressDTO>();

        private void SetupMocks()
        {
            addressRepo = addressRepoMock.Object;
            mapper = mapperMock.Object;
        }

        private void SetupAddressDTOMocks()
        {
            address = GetAddress();
            //var addressDTO = GetAddressDTO();

            mapperMock.Setup(o => o.Map<AddressDTO>(address))
                .Returns(GetAddressDTO());
        }
        private void SetupAddressDTOListMocks()
        {
            addressDTO = GetAddressDTO();
            var addressDTO2 = GetAddressDTO();
            addressDTO2.Id = 2;

            addressDTOList.Add(addressDTO);
            addressDTOList.Add(addressDTO2);

            addresses = GetAddresses();

            mapperMock.Setup(o => o.Map<List<AddressDTO>>(addresses))
                .Returns(addressDTOList);
        }

        private static Address GetAddress()
        {
            return new Address
            {
                Id = 4,
                Street = "Street4",
                City = "City4",
                Country = "Country4"
            };
        }

        private static AddressDTO GetAddressDTO()
        {
            return new AddressDTO
            {
                Id = 4,
                Street = "Street4",
                City = "City4",
                Country = "Country4"
            };
        }

        private static List<Address> GetAddresses()
        {
            return new List<Address>()
            {
                new Address()
                {
                Id = 1,
                Street = "Street1",
                City = "City1",
                Country = "Country1"
                },
                 new Address()
                 {
                    Id = 2,
                    Street = "Street2",
                    City = "City2",
                    Country = "Country2"
                 },
               new Address()
               {
                    Id = 3,
                    Street = "Street3",
                    City = "City3",
                    Country = "Country3"
               }
            };
        }

        [Fact]
        public void GetAddressByIdWhenCalledReturnsAddress()
        {
            //Arrange
            address = GetAddress();
            SetupMocks();
            SetupAddressDTOMocks();

            addressRepoMock
                .Setup(o => o.GetAddressById(It.IsAny<int>()))
                .Returns(address);

            var addressService = new AddressService(addressRepo);
            int id = 1;


            //Act 
            Address response = addressService.GetAddressById(id);

            //Assert
            Assert.True(response != null);
            Assert.NotNull(response);
            Assert.Equal(4, response.Id);
            Assert.NotEqual(id, response.Id);
        }

        [Fact]
        public void GetAddressesWhenCalledReturnsAddress()
        {
            //Arrage 
            addresses = GetAddresses();
            SetupMocks();
            SetupAddressDTOListMocks();

            addressRepoMock
            .Setup(o => o.GetAddresses())
            .Returns(addresses);

            var addressService = new AddressService(addressRepo);

            // Act
            List<Address> response = (List<Address>)addressService.GetAddresses();

            // Assert
            Assert.True(response != null);
        }

        [Fact]
        public void GetAddressesWhenCalledOnThreeAddressesReturnsTwoAddress()
        {
            //Arrange
            addresses = GetAddresses();
            SetupMocks();
            SetupAddressDTOListMocks();

            addressRepoMock
                .Setup(o => o.GetAddresses())
                .Returns(addresses);

            var addressService = new AddressService(addressRepo);

            //Act
            List<Address> response = (List<Address>)addressService.GetAddresses();

            //Assert
            Assert.NotNull(response);
            Assert.Equal(2, response.Count());
            Assert.NotEqual(1, response.Count());
        }
    }
}
